INSERT INTO `np_page` (`id`,`title`,`keywords`,`description`,`content`,`thumb`,`category_id`,`type_id`,`is_pass`,`is_com`,`is_top`,`is_hot`,`sort`,`hits`,`comment_count`,`username`,`origin`,`user_id`,`url`,`is_link`,`show_time`,`create_time`,`update_time`,`delete_time`,`access_id`,`lang`) VALUES ('1','关于我','','','&lt;p&gt;Hi，我是一员程序猿。&lt;/p&gt;

&lt;p&gt;这里主要记录工作中遇到的问题，以及经验总结。&lt;/p&gt;

&lt;p&gt;&lt;s&gt;还有最重要是测试自己写的这套PHP程序。&lt;/s&gt;&lt;/p&gt;

&lt;p&gt;&amp;lt; &amp;gt; &amp;lowast; , &amp;quot; &amp;#39; = _ - |&lt;/p&gt;','','4','0','1','0','0','0','0','184','0','','','1','','0','0','1471513383','1479890456','0','6','zh-cn');